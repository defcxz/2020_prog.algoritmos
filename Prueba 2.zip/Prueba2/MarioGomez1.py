suma_par = 0
mayor = 0
menor = 999999
divisible = ''
valida = True
while(valida == True):
    try:
        cantidad_numeros = int(input('Ingrese la cantidad de numeros que desea ingresar\n'))
        if(cantidad_numeros < 1):
            print('La cantidad debe ser entera y positiva')
        else:
            valida = False
    except:
        print('Debe ingresar un dato válido!')
x = 0
while(cantidad_numeros > x):
    x += 1
    print('- Numero',x,'-')
    valida = True
    while(valida == True):
        try:
            num = int(input('Ingrese el número.\n'))
            if(num < 1):
                print('La cantidad debe ser entera y positiva')
            else:
                valida = False
        except:
            print('Debe ingresar un dato válido!')
        if(num % 2 == 0):
            suma_par += num
        if(num > mayor):
            mayor = num
        if(num < menor):
            menor = num
        if(num % 8 == 0):
            divisible += str(num)+' '
print('='*40)
print('La suma de los números pares ingresados es:',suma_par)
print('El número mayor es',mayor,'y el número menor es',menor)
if(divisible != ''):
	print('Los números divisibles por 8 son:',divisible)
else:
	print('No se han encontrado números divisibles por 8 :(')
