suma = 0

valida = True
while(valida == True):
    try:
        n = int(input('Ingrese un número.\n'))
        
        if(n < 1):
            print('La cantidad debe ser entera y positiva')
        else:
            valida = False
    except:
        print('Debe ingresar un dato válido!')

while(n > 0):
    suma += n % 10
    n //= 10
print(suma)